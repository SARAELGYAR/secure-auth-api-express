const { isValidEmail } = require('../utils/validators.util');
const { isStrongPassword } = require('../utils/password.util');

/**
 * Middleware to validate user registration data
 */
const validateRegistration = (req, res, next) => {
  const { username, email, password, role } = req.body;

  // Check if all required fields are present
  if (!username || !email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Please provide username, email, and password.'
    });
  }

  // Validate username
  if (username.length < 3 || username.length > 30) {
    return res.status(400).json({
      success: false,
      message: 'Username must be between 3 and 30 characters.'
    });
  }

  // Validate email
  if (!isValidEmail(email)) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid email address.'
    });
  }

  // Validate password
  if (!isStrongPassword(password)) {
    return res.status(400).json({
      success: false,
      message: 'Password must be at least 8 characters long and contain at least 1 number and 1 special character.'
    });
  }

  // Validate role if provided
  const allowedRoles = ['user', 'moderator', 'admin'];
  if (role && !allowedRoles.includes(role)) {
    return res.status(400).json({
      success: false,
      message: 'Role must be one of: user, moderator, admin.'
    });
  }

  next();
};

/**
 * Middleware to validate user login data
 */
const validateLogin = (req, res, next) => {
  const { username, password } = req.body;

  // Check if all required fields are present
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Please provide username and password.'
    });
  }

  next();
};

/**
 * Middleware to validate profile update data
 */
const validateProfileUpdate = (req, res, next) => {
  const { email, password } = req.body;

  // Validate email if provided
  if (email && !isValidEmail(email)) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid email address.'
    });
  }

  // Validate password if provided
  if (password && !isStrongPassword(password)) {
    return res.status(400).json({
      success: false,
      message: 'Password must be at least 8 characters long and contain at least 1 number and 1 special character.'
    });
  }

  next();
};

/**
 * Middleware to validate role update
 */
const validateRoleUpdate = (req, res, next) => {
  const { role } = req.body;

  // Check if role is provided
  if (!role) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a role.'
    });
  }

  // Validate role
  const allowedRoles = ['user', 'moderator', 'admin'];
  if (!allowedRoles.includes(role)) {
    return res.status(400).json({
      success: false,
      message: 'Role must be one of: user, moderator, admin.'
    });
  }

  next();
};

module.exports = {
  validateRegistration,
  validateLogin,
  validateProfileUpdate,
  validateRoleUpdate
};