const express = require('express');
const authController = require('../controllers/auth.controller');
const { validateRegistration, validateLogin } = require('../middleware/validator.middleware');
const { authLimiter, registerLimiter } = require('../middleware/rateLimit.middleware');

const router = express.Router();

// Register a new user
router.post('/register', registerLimiter, validateRegistration, authController.register);

// Login
router.post('/login', authLimiter, validateLogin, authController.login);

module.exports = router;