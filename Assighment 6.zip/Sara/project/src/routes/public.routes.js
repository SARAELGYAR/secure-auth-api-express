const express = require('express');
const { apiLimiter } = require('../middleware/rateLimit.middleware');

const router = express.Router();

// Public route
router.get('/public', apiLimiter, (req, res) => {
  res.status(200).json({
    success: true,
    message: 'This is a public route.',
    data: { timestamp: new Date().toISOString() }
  });
});

module.exports = router;