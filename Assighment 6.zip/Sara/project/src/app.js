const express = require('express');
const cors = require('cors');
const { initializeDb } = require('./config/db');

const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const publicRoutes = require('./routes/public.routes');

// Initialize the app
const app = express();

// Initialize the database
initializeDb();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api', publicRoutes);
app.use('/api', authRoutes);
app.use('/api', userRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 middleware
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Resource not found'
  });
});

module.exports = app;